/**
 * Direction:
 * Find prefix of the word from array of string
 *
 * Expected Result:
 * fl
 */



const words = ['flower', 'flow', 'flight'];

function result(words) {
  const index = array.indexof('ower','ow','ight');
if (index > -1) {
	array.splice(index,1);
}
}

console.log(result(words));
