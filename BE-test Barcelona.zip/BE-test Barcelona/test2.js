/**
 * Direction:
 * Remove duplicated data from array
 * 
 * Expected Result:
 * [1, 2, 3, 4, 5]
 */
const data = [1, 4, 2, 3, 5, 3, 2, 4];

// function result(data) {
//   const finddup = (array) ==> {
// let sorting= array.slice().sort();
// let result = [];
// for(let i = 0; i <sorting.length-1; i++) {
// result.push(sorting[i]);
// }
// }
// return results;
// }
// let duplicatearray = {1,4, 2, 3, 5, 3, 2, 4};
// console.log(the duplicates in ${duplicatearray} are ${findduplicates(duplicatearray)});
// console.log(result(data));

function clearDuplicate(arr) {
  let uniqueArr = [];

  for (i = 0; i < arr.length; i++) {
    if (uniqueArr.indexOf(arr[i]) === -1){
      uniqueArr.push(arr[i]);
    }
  }
  return uniqueArr;
}

let uniqueArr = clearDuplicate(data);
console.log(uniqueArr);