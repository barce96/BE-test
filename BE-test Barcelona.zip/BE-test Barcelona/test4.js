/**
 * Direction:
 * Find missing number from the list
 *
 * Expected Result:
 * 8
 */
const numbers = [9, 6, 4, 2, 3, 5, 7, 0, 1];

function result(numbers) {
    // function getMissingNo(a, n) {
    //     let total = Math.floor((n + 1) * (n + 2) / 2);
    //     for (let i = 0; i < n; i++)
    //         total -= a[i];
    //     return total;
    // }
 
    // let arr = [ 9, 6, 4, 2, 3, 5, 7, 0 ];
    // let n = arr.length;
    // let miss = getMissingNo(arr, n);
    // document.write(miss);

    let missing = [];
    for (i = 0; i < numbers.length; i++) {
        if (numbers.indexOf(i) === -1){
            missing.push(i);
        }
    }
    return missing;
}

console.log(result(numbers));
